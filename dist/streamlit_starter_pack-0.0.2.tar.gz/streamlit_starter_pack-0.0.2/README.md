240402
-------

git clone 하여 우선 Layout을 적용하세요!


# 프로젝트 이름 : Streamlit Starter Pack

기본적으로 Streamlit 을 사용하면서 쓰일 기능들을 우선 넣었습니다.(240402)

## 시작하기

git clone을 통하여 로컬 저장소에 저장해놓으세요. 

### 설치하기

1. setup.cfg 내 package들 설치해야하므로, 

setup.cfg 가 있는 폴더트리로 이동 이후에 "pip install ." 실행해주세요. 